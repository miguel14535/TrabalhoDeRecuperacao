export interface Customer {
  id: number;
  nome: string;
  email: string;
  telefone: string;
}

export interface Order {
  id: number;
  id_cliente: number;
  data_pedido: string;
  valor_total: number;
  cliente_nome?: string; // For display purposes
}