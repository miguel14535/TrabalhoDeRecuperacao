import React, { useState, useEffect } from 'react';
import { Order } from '../types';
import { useStore } from '../context/StoreContext';

interface OrderFormProps {
  order?: Order;
  onSave: () => void;
  onCancel: () => void;
}

const OrderForm: React.FC<OrderFormProps> = ({ order, onSave, onCancel }) => {
  const { addOrder, updateOrder, customers } = useStore();
  const [idCliente, setIdCliente] = useState<number>(0);
  const [dataPedido, setDataPedido] = useState(new Date().toISOString().split('T')[0]);
  const [valorTotal, setValorTotal] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (order) {
      setIdCliente(order.id_cliente);
      setDataPedido(order.data_pedido);
      setValorTotal(order.valor_total.toString());
    } else if (customers.length > 0) {
      setIdCliente(customers[0].id);
    }
  }, [order, customers]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!idCliente) {
      newErrors.idCliente = 'Cliente é obrigatório';
    }
    
    if (!dataPedido) {
      newErrors.dataPedido = 'Data do pedido é obrigatória';
    }
    
    if (!valorTotal || isNaN(parseFloat(valorTotal)) || parseFloat(valorTotal) <= 0) {
      newErrors.valorTotal = 'Valor total deve ser um número positivo';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    const orderData = {
      id_cliente: idCliente,
      data_pedido: dataPedido,
      valor_total: parseFloat(valorTotal)
    };
    
    if (order) {
      updateOrder({
        ...orderData,
        id: order.id
      });
    } else {
      addOrder(orderData);
    }
    
    onSave();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="idCliente" className="block text-sm font-medium text-gray-700">
          Cliente*
        </label>
        <select
          id="idCliente"
          value={idCliente}
          onChange={(e) => setIdCliente(Number(e.target.value))}
          className={`mt-1 block w-full rounded-md border ${errors.idCliente ? 'border-red-500' : 'border-gray-300'} shadow-sm p-2`}
        >
          <option value="">Selecione um cliente</option>
          {customers.map(customer => (
            <option key={customer.id} value={customer.id}>
              {customer.nome}
            </option>
          ))}
        </select>
        {errors.idCliente && <p className="mt-1 text-sm text-red-600">{errors.idCliente}</p>}
      </div>
      
      <div>
        <label htmlFor="dataPedido" className="block text-sm font-medium text-gray-700">
          Data do Pedido*
        </label>
        <input
          type="date"
          id="dataPedido"
          value={dataPedido}
          onChange={(e) => setDataPedido(e.target.value)}
          className={`mt-1 block w-full rounded-md border ${errors.dataPedido ? 'border-red-500' : 'border-gray-300'} shadow-sm p-2`}
        />
        {errors.dataPedido && <p className="mt-1 text-sm text-red-600">{errors.dataPedido}</p>}
      </div>
      
      <div>
        <label htmlFor="valorTotal" className="block text-sm font-medium text-gray-700">
          Valor Total*
        </label>
        <div className="relative mt-1 rounded-md shadow-sm">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <span className="text-gray-500 sm:text-sm">R$</span>
          </div>
          <input
            type="number"
            id="valorTotal"
            value={valorTotal}
            onChange={(e) => setValorTotal(e.target.value)}
            step="0.01"
            min="0"
            className={`block w-full rounded-md border ${errors.valorTotal ? 'border-red-500' : 'border-gray-300'} pl-9 pr-12 p-2`}
            placeholder="0.00"
          />
        </div>
        {errors.valorTotal && <p className="mt-1 text-sm text-red-600">{errors.valorTotal}</p>}
      </div>
      
      <div className="flex justify-end space-x-2">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        >
          Cancelar
        </button>
        <button
          type="submit"
          className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          {order ? 'Atualizar' : 'Adicionar'}
        </button>
      </div>
    </form>
  );
};

export default OrderForm;