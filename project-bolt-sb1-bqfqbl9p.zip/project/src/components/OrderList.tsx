import React, { useState } from 'react';
import { Order } from '../types';
import { useStore } from '../context/StoreContext';
import OrderForm from './OrderForm';
import { Pencil, Trash2, ShoppingBag, Search, Calendar, DollarSign } from 'lucide-react';

const OrderList: React.FC = () => {
  const { orders, deleteOrder } = useStore();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | undefined>(undefined);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchBy, setSearchBy] = useState<'cliente' | 'data' | 'valor'>('cliente');

  const handleEdit = (order: Order) => {
    setSelectedOrder(order);
    setIsFormOpen(true);
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Tem certeza que deseja excluir este pedido?')) {
      deleteOrder(id);
    }
  };

  const handleAddNew = () => {
    setSelectedOrder(undefined);
    setIsFormOpen(true);
  };

  const handleFormClose = () => {
    setIsFormOpen(false);
    setSelectedOrder(undefined);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    const [year, month, day] = dateString.split('-');
    return `${day}/${month}/${year}`;
  };

  const filteredOrders = orders.filter(order => {
    if (searchTerm === '') return true;
    
    switch (searchBy) {
      case 'cliente':
        return order.cliente_nome?.toLowerCase().includes(searchTerm.toLowerCase());
      case 'data':
        return order.data_pedido.includes(searchTerm);
      case 'valor':
        const searchValue = parseFloat(searchTerm.replace(',', '.'));
        return !isNaN(searchValue) && order.valor_total === searchValue;
      default:
        return true;
    }
  });

  // Calculate summary statistics
  const totalOrders = filteredOrders.length;
  const totalValue = filteredOrders.reduce((sum, order) => sum + order.valor_total, 0);

  // Group orders by customer for summary
  const ordersByCustomer = filteredOrders.reduce((acc, order) => {
    const customerId = order.id_cliente;
    if (!acc[customerId]) {
      acc[customerId] = {
        customerName: order.cliente_nome || 'Unknown',
        orderCount: 0,
        totalValue: 0
      };
    }
    acc[customerId].orderCount += 1;
    acc[customerId].totalValue += order.valor_total;
    return acc;
  }, {} as Record<number, { customerName: string; orderCount: number; totalValue: number }>);

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-800">Pedidos</h2>
        <button
          onClick={handleAddNew}
          className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
        >
          <ShoppingBag size={18} className="mr-2" />
          Novo Pedido
        </button>
      </div>

      <div className="mb-4 flex">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder={`Buscar por ${searchBy === 'cliente' ? 'cliente' : searchBy === 'data' ? 'data (YYYY-MM-DD)' : 'valor'}`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-l-md"
          />
        </div>
        <select
          value={searchBy}
          onChange={(e) => setSearchBy(e.target.value as 'cliente' | 'data' | 'valor')}
          className="px-4 py-2 border border-l-0 border-gray-300 rounded-r-md bg-gray-50"
        >
          <option value="cliente">Cliente</option>
          <option value="data">Data</option>
          <option value="valor">Valor</option>
        </select>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
          <h3 className="text-lg font-medium text-blue-800 mb-2">Resumo de Pedidos</h3>
          <div className="flex justify-between">
            <div>
              <p className="text-sm text-blue-600">Total de Pedidos:</p>
              <p className="text-2xl font-bold text-blue-800">{totalOrders}</p>
            </div>
            <div>
              <p className="text-sm text-blue-600">Valor Total:</p>
              <p className="text-2xl font-bold text-blue-800">{formatCurrency(totalValue)}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-green-50 p-4 rounded-lg border border-green-100">
          <h3 className="text-lg font-medium text-green-800 mb-2">Pedidos por Cliente</h3>
          <div className="max-h-32 overflow-y-auto">
            {Object.values(ordersByCustomer).map((summary, index) => (
              <div key={index} className="flex justify-between text-sm mb-1">
                <span className="text-green-700">{summary.customerName}</span>
                <span className="text-green-800 font-medium">
                  {summary.orderCount} pedidos ({formatCurrency(summary.totalValue)})
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {isFormOpen ? (
        <div className="mb-6 p-4 border border-gray-200 rounded-md bg-gray-50">
          <h3 className="text-lg font-medium mb-4">
            {selectedOrder ? 'Editar Pedido' : 'Novo Pedido'}
          </h3>
          <OrderForm
            order={selectedOrder}
            onSave={handleFormClose}
            onCancel={handleFormClose}
          />
        </div>
      ) : null}

      {filteredOrders.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ID
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cliente
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Valor
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredOrders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {order.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {order.cliente_nome}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {order.data_pedido ? formatDate(order.data_pedido) : ''}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatCurrency(order.valor_total)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => handleEdit(order)}
                      className="text-indigo-600 hover:text-indigo-900 mr-3"
                    >
                      <Pencil size={18} />
                    </button>
                    <button
                      onClick={() => handleDelete(order.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center py-4 text-gray-500">
          {searchTerm ? 'Nenhum pedido encontrado com os critérios de busca.' : 'Nenhum pedido registrado.'}
        </div>
      )}
    </div>
  );
};

export default OrderList;