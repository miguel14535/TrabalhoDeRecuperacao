import React from 'react';
import { ShoppingBag, Users } from 'lucide-react';

interface NavbarProps {
  activeTab: 'customers' | 'orders';
  setActiveTab: (tab: 'customers' | 'orders') => void;
}

const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  return (
    <nav className="bg-blue-800 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <ShoppingBag size={24} className="mr-2" />
            <span className="font-bold text-xl">Sistema de Loja</span>
          </div>
          <div className="flex">
            <button
              onClick={() => setActiveTab('customers')}
              className={`flex items-center px-4 py-2 mx-1 rounded-md ${
                activeTab === 'customers'
                  ? 'bg-blue-900 text-white'
                  : 'text-blue-100 hover:bg-blue-700'
              }`}
            >
              <Users size={18} className="mr-2" />
              Clientes
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`flex items-center px-4 py-2 mx-1 rounded-md ${
                activeTab === 'orders'
                  ? 'bg-blue-900 text-white'
                  : 'text-blue-100 hover:bg-blue-700'
              }`}
            >
              <ShoppingBag size={18} className="mr-2" />
              Pedidos
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;