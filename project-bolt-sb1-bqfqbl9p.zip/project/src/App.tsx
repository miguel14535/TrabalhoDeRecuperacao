import React, { useState } from 'react';
import { StoreProvider } from './context/StoreContext';
import CustomerList from './components/CustomerList';
import OrderList from './components/OrderList';
import Navbar from './components/Navbar';

function App() {
  const [activeTab, setActiveTab] = useState<'customers' | 'orders'>('customers');

  return (
    <StoreProvider>
      <div className="min-h-screen bg-gray-100">
        <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
        
        <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          <div className="px-4 py-6 sm:px-0">
            {activeTab === 'customers' ? (
              <CustomerList />
            ) : (
              <OrderList />
            )}
          </div>
        </main>
        
        <footer className="bg-white shadow-inner py-4 mt-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <p className="text-center text-gray-500 text-sm">
              Sistema de Gerenciamento de Loja © 2023
            </p>
          </div>
        </footer>
      </div>
    </StoreProvider>
  );
}

export default App;