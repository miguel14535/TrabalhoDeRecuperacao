import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Customer, Order } from '../types';

interface StoreContextType {
  customers: Customer[];
  orders: Order[];
  addCustomer: (customer: Omit<Customer, 'id'>) => void;
  updateCustomer: (customer: Customer) => void;
  deleteCustomer: (id: number) => void;
  addOrder: (order: Omit<Order, 'id'>) => void;
  updateOrder: (order: Order) => void;
  deleteOrder: (id: number) => void;
  getCustomerById: (id: number) => Customer | undefined;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};

interface StoreProviderProps {
  children: ReactNode;
}

export const StoreProvider: React.FC<StoreProviderProps> = ({ children }) => {
  const [customers, setCustomers] = useState<Customer[]>([
    { id: 1, nome: 'João Silva', email: 'joao@example.com', telefone: '(11) 98765-4321' },
    { id: 2, nome: 'Maria Oliveira', email: 'maria@example.com', telefone: '(21) 91234-5678' },
  ]);
  
  const [orders, setOrders] = useState<Order[]>([
    { 
      id: 1, 
      id_cliente: 1, 
      data_pedido: '2023-05-15', 
      valor_total: 150.75,
      cliente_nome: 'João Silva'
    },
    { 
      id: 2, 
      id_cliente: 2, 
      data_pedido: '2023-05-20', 
      valor_total: 89.90,
      cliente_nome: 'Maria Oliveira'
    },
  ]);

  const addCustomer = (customer: Omit<Customer, 'id'>) => {
    const newId = customers.length > 0 ? Math.max(...customers.map(c => c.id)) + 1 : 1;
    setCustomers([...customers, { ...customer, id: newId }]);
  };

  const updateCustomer = (updatedCustomer: Customer) => {
    setCustomers(customers.map(customer => 
      customer.id === updatedCustomer.id ? updatedCustomer : customer
    ));
    
    // Update customer name in orders
    setOrders(orders.map(order => 
      order.id_cliente === updatedCustomer.id 
        ? { ...order, cliente_nome: updatedCustomer.nome } 
        : order
    ));
  };

  const deleteCustomer = (id: number) => {
    // Check if customer has orders
    const hasOrders = orders.some(order => order.id_cliente === id);
    if (hasOrders) {
      alert('Não é possível excluir um cliente que possui pedidos.');
      return;
    }
    
    setCustomers(customers.filter(customer => customer.id !== id));
  };

  const addOrder = (order: Omit<Order, 'id'>) => {
    const newId = orders.length > 0 ? Math.max(...orders.map(o => o.id)) + 1 : 1;
    const customer = customers.find(c => c.id === order.id_cliente);
    
    setOrders([...orders, { 
      ...order, 
      id: newId,
      cliente_nome: customer?.nome
    }]);
  };

  const updateOrder = (updatedOrder: Order) => {
    const customer = customers.find(c => c.id === updatedOrder.id_cliente);
    
    setOrders(orders.map(order => 
      order.id === updatedOrder.id 
        ? { ...updatedOrder, cliente_nome: customer?.nome } 
        : order
    ));
  };

  const deleteOrder = (id: number) => {
    setOrders(orders.filter(order => order.id !== id));
  };

  const getCustomerById = (id: number) => {
    return customers.find(customer => customer.id === id);
  };

  return (
    <StoreContext.Provider value={{
      customers,
      orders,
      addCustomer,
      updateCustomer,
      deleteCustomer,
      addOrder,
      updateOrder,
      deleteOrder,
      getCustomerById
    }}>
      {children}
    </StoreContext.Provider>
  );
};