# Sistema de Gerenciamento de Loja

Um sistema completo para gerenciamento de clientes e pedidos de uma loja, desenvolvido com React, TypeScript e Tailwind CSS.

## Funcionalidades

- Cadastro, edição e exclusão de clientes
- Registro, edição e exclusão de pedidos
- Busca de clientes por nome, email ou telefone
- Busca de pedidos por cliente, data ou valor
- Resumo estatístico de pedidos
- Interface responsiva e amigável

## Tecnologias Utilizadas

- React 18
- TypeScript
- Tailwind CSS
- Lucide React (para ícones)
- Context API (para gerenciamento de estado)

## Como Executar

1. Clone o repositório:
   ```bash
   git clone https://github.com/seu-usuario/sistema-gerenciamento-loja.git
   cd sistema-gerenciamento-loja
   ```

2. Instale as dependências:
   ```bash
   npm install
   ```

3. Execute o projeto:
   ```bash
   npm run dev
   ```

4. Acesse o aplicativo em seu navegador:
   ```
   http://localhost:5173
   ```

## Estrutura do Projeto

- `/src/components`: Componentes React reutilizáveis
- `/src/context`: Context API para gerenciamento de estado
- `/src/types`: Definições de tipos TypeScript

## Licença

MIT